package com.example.noiselevel;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText loginEmailEditText;
    private EditText loginPasswordEditText;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);
        loginEmailEditText = findViewById(R.id.loginEmailEditText);
        loginPasswordEditText = findViewById(R.id.loginPasswordEditText);

        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle login logic here
                String email = loginEmailEditText.getText().toString();
                String password = loginPasswordEditText.getText().toString();

                if (isValid(email, password)) {
                    // Check if the user exists in the database
                    if (checkUser(email, password)) {
                        Toast.makeText(LoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                        // You can navigate to the main activity or perform other actions here
                    } else {
                        Toast.makeText(LoginActivity.this, "Login failed. Invalid credentials.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid input. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isValid(String email, String password) {
        // Implement your validation logic here
        return !email.isEmpty() && !password.isEmpty();
    }

    private boolean checkUser(String email, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {DatabaseContract.UserEntry.COLUMN_EMAIL, DatabaseContract.UserEntry.COLUMN_PASSWORD};
        String selection = DatabaseContract.UserEntry.COLUMN_EMAIL + " = ? AND " +
                DatabaseContract.UserEntry.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {email, password};
        Cursor cursor = db.query(
                DatabaseContract.UserEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        if (cursor != null && cursor.moveToFirst()) {
            cursor.close();
            return true; // User exists
        } else {
            return false; // User doesn't exist or invalid credentials
        }
    }
}
