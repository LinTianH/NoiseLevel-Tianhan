package com.example.noiselevel;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.FragmentActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private DatabaseHelper dbHelper;
    private EditText noiseLevelEditText;
    private Button submitButton;
    private Button enableGPSButton;
    private static final int REQUEST_LOCATION_PERMISSION = 1;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this); // Initialize the database helper

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // Initialize UI Elements
        noiseLevelEditText = findViewById(R.id.noiseLevelEditText);
        submitButton = findViewById(R.id.submitButton);
        enableGPSButton = findViewById(R.id.enableGPSButton); //Initialize the GPS Button

        // Check for location permissions
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Location permission is not granted, request it from the user
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);
        } else {
            // Location permission is already granted, proceed with map setup
            setupMap();
        }

        // Submit button click listener
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get noise level input from the EditText
                String noiseLevelStr = noiseLevelEditText.getText().toString();

                //Validate input
                if (!TextUtils.isEmpty(noiseLevelStr)) {
                    //Convert input to a double
                    double noiseLevel = Double.parseDouble(noiseLevelStr);

                    //Call a method to send the data to the server
                    sendNoiseLevelToServer(noiseLevel);
                } else {
                    //Handle empty input or the validation errors
                    Toast.makeText(MainActivity.this, "Please enter a valid noise level.",Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Historical data button click listener
        findViewById(R.id.historicalDataButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openHistoricalDataActivity();
            }
        });

        // Exit button click listener
        findViewById(R.id.exitButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showExitDialog();
            }
        });

        // Enable GPS button click listener
        enableGPSButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open device location settings
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        });

    }

    // Method to set up the map
    private void setupMap() {
        // Check if GPS is enabled
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (locationManager != null && !locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            // GPS is not enabled, show the "Enable GPS" button
            enableGPSButton.setVisibility(View.VISIBLE);
        } else {
            // GPS is enabled, hide the "Enable GPS" button
            enableGPSButton.setVisibility(View.GONE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Location permission granted, proceed with map setup
                setupMap();
            } else {
                // Location permission denied, show a message or handle it as needed
                Toast.makeText(this, "Location permission denied. You can enable it in app settings.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Display historical noise data
        displayHistoricalData();

        // Example noise data
        NoiseData kamparNoiseData = new NoiseData(75.5, System.currentTimeMillis());

        // Get noise level and coordinates from the NoiseData object
        double kamparNoiseLevel = kamparNoiseData.getKamparNoiseLevel();
        LatLng kamparCoordinates = new LatLng(4.3065, 101.1432); // Kampar coordinates

        MarkerOptions markerOptions = new MarkerOptions()
                .position(kamparCoordinates)
                .title(getString(R.string.current_noise) + " " + kamparNoiseLevel);

        Marker marker = mMap.addMarker(markerOptions);
        marker.setTag(kamparNoiseData); // Store the NoiseData object as a tag for the marker

        mMap.moveCamera(CameraUpdateFactory.newLatLng(kamparCoordinates));

        // Save historical noise level data
        saveHistoricalData(kamparNoiseData);
    }

    // Method to send noise level data to the server
    private void sendNoiseLevelToServer(double noiseLevel) {
        //Define the server URL Components
        String protocol = "https"; //https has more secure connections
        String domain = "example.com"; //Replace it with domain or IP Address
        int port = 443;
        String path = "api/submit_noise_level"; //specify the path to API endpoint

        //Create the URL
        String serverUrl = protocol + "://" + domain + ":" + port + path;

        //Create an AsyncTask to send the data
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    // Prepare the data to send to the server
                    JSONObject jsonData = new JSONObject();
                    jsonData.put("noise_level", noiseLevel);

                    // Create a URL object from the server URL
                    URL url = new URL(serverUrl);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);

                    // Write the data to the output stream
                    OutputStream os = connection.getOutputStream();
                    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                    writer.write(jsonData.toString());
                    writer.flush();
                    writer.close();
                    os.close();

                    // Get the response from the server (you can handle it as needed)
                    int responseCode = connection.getResponseCode();
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        // Data sent successfully
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "Noise level data sent successfully.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        // Handle server response (e.g., error messages)
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "Failed to send noise level data.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    // Handle network or other exceptions
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "An error occurred. Please try again later.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                return null;
            }
        }.execute();
    }

    //Open HistoricalDataActivity
    private void openHistoricalDataActivity() {
        Intent intent = new Intent(this, HistoricalDataActivity.class);
        startActivity(intent);
    }

    // To retrieve and display historical data
    private void displayHistoricalData(){
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] projection = {
                DatabaseContract.HistoryEntry.COLUMN_NOISE_LEVEL,
                DatabaseContract.HistoryEntry.COLUMN_TIMESTAMP
        };

        Cursor cursor = db.query(
                DatabaseContract.HistoryEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") double noiseLevel = cursor.getDouble(cursor.getColumnIndex(DatabaseContract.HistoryEntry.COLUMN_NOISE_LEVEL));
                @SuppressLint("Range") long timestamp = cursor.getLong(cursor.getColumnIndex(DatabaseContract.HistoryEntry.COLUMN_TIMESTAMP));

                // Check if the noise level and timestamp are valid
                if (noiseLevel >= 0 && timestamp >= 0) {
                    // Create a LatLng objects with coordinates of your choice
                    LatLng coordinates = new LatLng(4.3065, 101.1432);

                    MarkerOptions markerOptions = new MarkerOptions()
                            .position(coordinates)
                            .title(getString(R.string.marker_title) + " " + noiseLevel)
                            .snippet(getString(R.string.marker_timestamp) + " " + timestamp);

                    mMap.addMarker(markerOptions);
                } else {
                    Log.e("InvalidData", "Invalid noise level or timestamp: " +
                            "Noise Level: " + noiseLevel + ", Timestamp: " + timestamp);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            } while (cursor.moveToNext());

            cursor.close();
        }
    }

    // Show an error dialog to the user
    private void showErrorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.error_occurred)
                .setMessage(R.string.invalid_data_detected)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Close the dialog
                        dialogInterface.dismiss();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    private void saveHistoricalData(NoiseData noiseData) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseContract.HistoryEntry.COLUMN_NOISE_LEVEL, noiseData.getKamparNoiseLevel());
        values.put(DatabaseContract.HistoryEntry.COLUMN_TIMESTAMP, noiseData.getTimestamp());

        long newRowId = db.insert(DatabaseContract.HistoryEntry.TABLE_NAME, null, values);
        if (newRowId != -1) {
            Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.save_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private void showExitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.exit_confirmation)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish(); // Close the app
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Dismiss the dialog
                        dialog.dismiss();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
